#include "common/problem.h"

namespace cb = common::base;

Colour getErrorBackground() { return RED; }
