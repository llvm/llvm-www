#include "common/base.h"

namespace common {

// Don't restate 'common::'.
Colour function();

}

