#include "common/problem.h"

void foo() {
  namespace common::base = cb;
  // ...
}

void bar() {
  Colour x = WHITE;
}
