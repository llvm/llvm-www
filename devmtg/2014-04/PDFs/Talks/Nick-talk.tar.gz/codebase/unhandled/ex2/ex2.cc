#include "common/problem.h"

DrawState::Winding f1() { return DrawState::CW; }
common::base::DrawState::Winding f2() { return common::base::DrawState::CW; }
