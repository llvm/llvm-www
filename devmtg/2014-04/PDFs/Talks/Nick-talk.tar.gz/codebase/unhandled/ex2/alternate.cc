#include "common/problem.h"

namespace common {
namespace base {
struct B {
  struct C;
};
}
}
typedef common::base::B A;
struct A::C {
} a;
