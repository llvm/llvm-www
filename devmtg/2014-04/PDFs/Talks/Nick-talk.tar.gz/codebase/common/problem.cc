#include "problem.h"

Colour getRowColour(int row_number) {
  return row_number % 2 ? WHITE : OFFWHITE;
}
