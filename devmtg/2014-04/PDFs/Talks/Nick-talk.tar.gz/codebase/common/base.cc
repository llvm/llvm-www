#include "base.h"

namespace common {
namespace base {

Drawable::Drawable() {}
Drawable::~Drawable() {}

bool Colour_IsValid(int value) {
  return value >= Colour_MIN && value <= NUM_COLOURS;
}
}
}
