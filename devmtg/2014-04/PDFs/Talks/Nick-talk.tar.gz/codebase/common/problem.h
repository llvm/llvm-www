#include "base.h"

// Need this for compatibility.
using namespace common::base;

Colour getRowColour(int row_number);
