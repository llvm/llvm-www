#include "common/problem.h"

using common::base::Colour;
using common::base::WHITE;

Colour getColourForA() { return WHITE; }
Colour getColourForB() { return WHITE; }
Colour getColourForC() { return OFFWHITE; }
Colour getColourForD() { return WHITE; }
Colour getColourForE() { return RED; }
