#include "common/problem.h"

common::base::Colour f1() { return common::base::RED; }
common::base   ::   Colour f2() { return common::base   ::   RED; }
Colour f3() { return RED; }

Coord g();
struct Coord g();
common::base::Coord g();
struct common::base::Coord g();

Coord x1;
struct Coord x2;
common::base::Coord x3;
struct common::base::Coord x4;
